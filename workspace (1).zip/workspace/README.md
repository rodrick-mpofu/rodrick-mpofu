- 👋 Hi, I’m @rodrick-mpofu
- 👀 I’m interested in hip-hop music, soccer/football and dance
- 🌱 I’m currently learning Data Science at St. Lawrence University
- 💞️ I’m looking to collaborate on Data Science or Computer Science related projects

<!---
rodrick-mpofu/rodrick-mpofu is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
